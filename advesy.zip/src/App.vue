<template>
  <div id="app">
    <router-view></router-view>
  </div>
</template>
<style lang="scss">
  *{
    margin: 0;
    padding: 0;
    list-style: name;
  }
  html,body,#app{
 height: 100%;
}
</style>
